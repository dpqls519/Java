
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class CellGame extends JPanel implements Runnable {
	Frame frame;

	Image BackImage;

	ArrayList<Jewel> jewels;
	ArrayList<Bomb> bombs;

	static int x, y;
	static int cellSize;
	int score = 0;
	int gameCount = 10;
	int speed = 5;
	int xDir = 0, yDir = 0;
	boolean isLoop = true;

	Random random = new Random();

	Thread cellgame;

	public CellGame(Frame frame) {

		this.frame = frame;
		x = 10;
		y = 10;
		cellSize = 50;

		jewels = new ArrayList<Jewel>(); // jewel ����
		for (int i = 0; i < 100; i++) {
			jewels.add(new Jewel());
		}

		bombs = new ArrayList<Bomb>(); // Bomb ����
		for (int i = 0; i < 5; i++) {
			bombs.add(new Bomb());
		}

		Sound.StartSound("Bright_Wish.wav"); // sound ���

		MyListener myListener = new MyListener();
		frame.addKeyListener(myListener);

		cellgame = new Thread(this); // cell game����
		cellgame.start();
	}

	@Override
	public void run() {
		while (!(gameCount == 0 || cellSize < 20)) {
			x += xDir;
			y += yDir;

			Iterator<Jewel> iter = jewels.iterator();
			Iterator<Bomb> iter1 = bombs.iterator();

			if ((x <= 0) || (x >= (Frame.WIDTH - (cellSize + 20)))) { // ���� �ε����� ƨ��
				xDir = -xDir;
			}
			if ((y <= 0) || (y >= (Frame.HEIGHT - (cellSize + 30)))) {
				yDir = -yDir;
			}

			while (iter.hasNext()) {
				Jewel jewel = iter.next();
				int xDiff = (x + cellSize / 2) - (jewel.getX() + jewel.getSize() / 2);
				int yDiff = (y + cellSize / 2) - (jewel.getY() + jewel.getSize() / 2);
				double length = Math.sqrt(xDiff * xDiff + yDiff * yDiff);
				// cell�� jewel�� �Ծ�����
				if (length < cellSize / 2) {
					cellSize = cellSize + jewel.getSize() / 10;
					score += jewel.getSize(); // ���� �߰�
					iter.remove();
				}
			}

			while (iter1.hasNext()) {
				Bomb bomb = iter1.next();
				int xDiff = (x + cellSize / 2) - (bomb.getX() + bomb.getSize() / 2);
				int yDiff = (y + cellSize / 2) - (bomb.getY() + bomb.getSize() / 2);
				Double length = Math.sqrt(xDiff * xDiff + yDiff * yDiff);
				// cell�� bomb�� �Ծ�����
				if (length < cellSize / 2) {
					score -= bomb.getSize(); // ���� ����
					cellSize = cellSize / 2; // - bomb.getSize();
					iter1.remove();
					gameCount--;
				}
			}

			if (jewels.isEmpty()) { // ������ �� �Ծ����� �ٽ� �����
				for (int i = 0; i < 100; i++) {
					jewels.add(new Jewel());
				}
			}

			if (bombs.isEmpty()) { // ��ź�� �� �Ծ����� �ٽ� �����
				for (int i = 0; i < 5; i++) {
					bombs.add(new Bomb());
				}
			}

			if (gameCount == 0 || cellSize < 20) { // ����ī��Ʈ�� 0�̰ų� cellSize�� 20�̸��̸� ���� ����
				Sound.StopSound(); // sound ����
				frame.change("FinishPanel"); // finishpanel�� ��ȯ
			}

			try {
				Thread.sleep(speed);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			frame.repaint();
		}
	}

	public void paintComponent(Graphics g) {
		BackImage = new ImageIcon("background.jpg").getImage();
		super.paintComponent(g);

		g.drawImage(BackImage, 0, 0, null); // ���׸���

		g.setColor(new Color(0x9999FF)); // cell �׸���
		g.fillRoundRect(x, y, cellSize, cellSize, 15, 15);
		g.setColor(Color.black);
		g.drawRoundRect(x, y, cellSize, cellSize, 15, 15);

		for (Jewel jewel : jewels) { // jewel �׸���
			g.setColor(jewel.getColor());
			g.fillOval(jewel.getX(), jewel.getY(), jewel.getSize(), jewel.getSize());
			g.setColor(Color.black);
			g.drawOval(jewel.getX(), jewel.getY(), jewel.getSize(), jewel.getSize());
		}

		for (Bomb bomb : bombs) { // bomb �׸���
			g.setColor(Color.black);
			g.fillOval(bomb.getX(), bomb.getY(), bomb.getSize(), bomb.getSize());
			g.setColor(Color.red);
			g.drawOval(bomb.getX(), bomb.getY(), bomb.getSize(), bomb.getSize());
		}

		g.setColor(Color.black);
		g.setFont(new Font(null, Font.BOLD, 20));

		g.drawString("Score : " + score, 10, 30); // ���� ǥ���ϱ�

		g.drawString("Life : " + gameCount, 1150, 30); // gamecount ǥ���ϱ�

		g.drawString("Size : " + cellSize, 1150, 50); // life ǥ���ϱ�
	}

	private class MyListener implements KeyListener {

		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
		}

		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub
			switch (e.getKeyCode()) {
			case KeyEvent.VK_UP:
				yDir = -1;
				xDir = 0;
				break;
			case KeyEvent.VK_DOWN:
				yDir = 1;
				xDir = 0;
				break;
			case KeyEvent.VK_LEFT:
				xDir = -1;
				yDir = 0;
				break;
			case KeyEvent.VK_RIGHT:
				xDir = 1;
				yDir = 0;
				break;
			}
		}

		@Override
		public void keyReleased(KeyEvent e) {
			// TODO Auto-generated method stub
		}
	}
}