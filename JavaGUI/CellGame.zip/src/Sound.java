import java.io.BufferedInputStream;
import java.io.FileInputStream;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class Sound {
	static boolean isLoop = true;
	static Clip clip;

	public Sound() {

	}

	public static void StartSound(String file) { // sound����
		try {
			AudioInputStream ais = AudioSystem.getAudioInputStream(new BufferedInputStream(new FileInputStream(file)));
			clip = AudioSystem.getClip();
			clip.open(ais);
			clip.start();
			if (isLoop = true) // sound ���ѹݺ�
				clip.loop(-1);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void StopSound() { // sound����
		// TODO Auto-generated method stub
		clip.stop();
		clip.close();
	}
}