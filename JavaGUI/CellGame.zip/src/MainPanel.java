import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class MainPanel extends JPanel {
	Frame frame;
	Image IntroImage;
	private JButton Start, Exit;

	public MainPanel(Frame frame) {
		this.frame = frame;

		setLayout(null);

		IntroImage = new ImageIcon("Intro.jpg").getImage();
		Start = new JButton(new ImageIcon(CellGameDriver.class.getResource("./Images/Start.PNG")));
		Exit = new JButton(new ImageIcon(CellGameDriver.class.getResource("./Images/Exit.PNG")));

		Start.setBorderPainted(false);
		Start.setContentAreaFilled(false);
		Start.setFocusPainted(false);

		Exit.setBorderPainted(false);
		Exit.setContentAreaFilled(false);
		Exit.setFocusPainted(false);

		Start.setBounds(200, 500, 248, 140);
		Exit.setBounds(850, 500, 248, 140);

		add(Start);
		add(Exit);

		Start.addMouseListener(new MyMouseListener());
		Exit.addMouseListener(new MyMouseListener());
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		g.drawImage(IntroImage, 0, 0, null); // ���׸���
	}

	private class MyMouseListener extends MouseAdapter {
		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			if (e.getSource() == Start) {
				frame.change("cellgame");
			} else
				System.exit(0);

		}
	}
}
