import java.awt.Color;
import java.util.Random;

public class Jewel {
	private int x;
	private int y;
	private int size;
	private Color color;
	Random random = new Random();

	public Jewel() {
		size = random.nextInt(CellGame.cellSize / 2) + 15; // ���� ũ�� ����
		x = 5 + random.nextInt(Frame.WIDTH - CellGame.cellSize * 2);
		y = 5 + random.nextInt(Frame.HEIGHT - CellGame.cellSize * 2);
		color = new Color((random.nextInt(0x146)) + (0xFAEB78));
	}

	public int getX() {
		return this.x;
	}

	public int getY() {
		return this.y;
	}

	public int getSize() {
		return this.size;
	}

	public Color getColor() {
		return color;
	}
}
