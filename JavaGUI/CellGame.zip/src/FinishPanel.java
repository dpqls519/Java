import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class FinishPanel extends JPanel {
	Frame frame;
	Image FinishImage;
	private JButton Restart, Exit;

	public FinishPanel(Frame frame) {
		this.frame = frame;

		setLayout(null);

		FinishImage = new ImageIcon("Finish.jpg").getImage();
		Restart = new JButton(new ImageIcon(CellGameDriver.class.getResource("./Images/Restart.PNG")));
		Exit = new JButton(new ImageIcon(CellGameDriver.class.getResource("./Images/Exit.PNG")));

		Restart.setBorderPainted(false);
		Restart.setContentAreaFilled(false);
		Restart.setFocusPainted(false);

		Exit.setBorderPainted(false);
		Exit.setContentAreaFilled(false);
		Exit.setFocusPainted(false);

		Restart.setBounds(200, 500, 248, 140);
		Exit.setBounds(850, 500, 248, 140);

		add(Restart);
		add(Exit);

		Restart.addMouseListener(new MyMouseListener());
		Exit.addMouseListener(new MyMouseListener());
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		g.drawImage(FinishImage, 0, 0, null); // ���׸���
	}

	private class MyMouseListener extends MouseAdapter {
		@Override
		public void mouseClicked(MouseEvent e) {
			if (e.getSource() == Restart) {
				frame.change("cellgame");
			} else
				System.exit(0);

		}
	}
}