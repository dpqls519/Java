import java.awt.Container;

import javax.swing.JFrame;

public class Frame extends JFrame {

	Container c = this.getContentPane();

	static int WIDTH = 1280, HEIGHT = 780;
	private MainPanel main = new MainPanel(this);
	private FinishPanel finish = new FinishPanel(this);
	private CellGame cellgame = null;
	JFrame frame;

	public Frame() {
		setSize(WIDTH, HEIGHT);

		c.add(main);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setLocationRelativeTo(null); // ȭ�� �߰��� ����

		setFocusable(true);
		requestFocus();
	}

	public void change(String name) { // panel����
		if (name.equals("cellgame")) { // cellgame���� ����
			c.removeAll();
			cellgame = new CellGame(this);
			c.add(cellgame);
			revalidate();
			repaint();
		} else if (name.equals("FinishPanel")) { // finishpanel�� ����
			c.removeAll();
			cellgame = null;
			finish = new FinishPanel(this);
			c.add(finish);
			revalidate();
			repaint();
		}
	}
}
