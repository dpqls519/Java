import java.util.Random;

public class Bomb {
	private int x;
	private int y;
	private int size;
	Random random = new Random();

	public Bomb() {
		size = random.nextInt(CellGame.cellSize / 2) + 15; // ��ź ũ�� ����
		x = 5 + random.nextInt(Frame.WIDTH - CellGame.cellSize * 2);
		y = 5 + random.nextInt(Frame.HEIGHT - CellGame.cellSize * 2);
	}

	public void setX(int x) {
		this.x = x;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getX() {
		return this.x;
	}

	public int getY() {
		return this.y;
	}

	public int getSize() {
		return this.size;
	}

}
