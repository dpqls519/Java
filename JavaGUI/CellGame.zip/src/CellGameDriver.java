public class CellGameDriver {

	public static void main(String[] args) {
		new Frame();
	}
}